//This is pageobject file.
/// <reference types="cypress" />
 
export class Homepage {
    EnterURL(){
    return  cy.visit("https://www.energyaustralia.com.au/");
    }
    VerifyLogo(){
     return cy.get('.navbar--mobile > .navbar-brand > .site-logo');
     }
     searchResults(){
         return cy.get('h3').first();
     }
  }