//This is spec file, inside your google-search.spec.ts
//import { GoogleSearch } from "../integration/src/page-objects/google-search.page";
import { GoogleSearch } from "./page-object/google-search.page";
const search = new GoogleSearch();
describe('Google Navigation', () => {
    it('Google Search', () => {
    cy.visit('https://www.google.com')
    cy.get('#APjFqb').type("Cypress")
    cy.get('#hwdq1 > .wM6W7d > span').click();
     
 
    });
});//textarea[@id='APjFqb']