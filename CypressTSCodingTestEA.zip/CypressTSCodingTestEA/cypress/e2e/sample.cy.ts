describe ('Test Suite', function()

{

    beforeEach( ()=> {     // before execute it blocks  
        cy.visit("https://www.energyaustralia.com.au/");  })
   
it ('Test1 - Verify Energy Australia Logo is visible', function() {
    cy.get('.navbar--mobile > .navbar-brand > .site-logo')
     cy.wait(3000)
})


})