import { Homepage } from "./page-object/Homepage";
const search = new Homepage
describe ('Test Suite', function()

{

    beforeEach( ()=> {     // before execute it blocks  
       cy.visit("https://www.energyaustralia.com.au/");  })
       //search.EnterURL();
it ('Test1 - Verify Energy Australia Logo is visible', function() {
    cy.get('.navbar--mobile > .navbar-brand > .site-logo').should('have.attr', 'src','/themes/custom/ea/assets/images/EA_logo.svg')
    //search.VerifyLogo();
     cy.wait(3000)
})
it ('Test2 - Open Go Green Page and verify title', function() {
    cy.get('a[href*="/home/electricity-and-gas"]').invoke('show')        
    cy.contains ('Go green').click({force:true}) 
    cy.url().should('include', 'go-green') 
     cy.wait(2000)


})


it ('Test3 - select Home & Verify postcode & Enter Postcode', function() {
    cy.get('a[href*="/offer"]').contains('Home').click().wait(2000)
    //cy.get('#modal-heading-campaignPopupId').should('include', 'Enter your postcode to begin') // partial match
    let expname:string ="Enter your postcode to begin"
    cy.get('#modal-heading-campaignPopupId').then ( (x) => {
       let actname:string =x.text() 
      expect (actname).to.equal(expname) 
})

let postcode:number= 3030
cy.get('.campaign-search-form__postcode').clear().wait(3000)
cy.get('#campaign-modal-location-refine-postcode-input').type ("3030")
cy.get('#campaign-modal-search-submit').click()

}) 

/*
<a href="/home/electricity-and-gas" data-drupal-link-system-path="node/14940" xpath="1">Electricity and gas</a>

cy.wait(2000)
cy.get('.campaign-search-form__postcode').clear().type(3030)
cy.get('#campaign-modal-search-submit').click()

cy.get('#edit-refine-location-type-address__label').click()

    cy.get('#address-auto-input').type('18 Calypso Cr').wait(500)
    cy.get('#edit-address-auto-0').click()

    cy.get('#action__submit').click().wait(2000)
    
    cy.get('#edit-new-existing-new__label').click()
   // cy.get('//label[@id="edit-new-existing-new__label"]').click()

    cy.get('#edit-moving-or-not-yes__label').click()
    cy.get('img[alt="Next month"]').click()
    cy.get('#edit-qualifier-connection-datepicker-2023-07-20').click()

    cy.get('//label[@id="edit-customer-property-relationship-renter__label"]').click()
*/
//after ( ()=> {     // this will run after execute all it blocks or only once
    //cy.log ("...Close browser  ")  })



})


